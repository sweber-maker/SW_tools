import io, re, time
from urllib.parse import urlparse, quote
import requests
import pandas as pd
import streamlit as st
from bs4 import BeautifulSoup
from Bio.SeqUtils.ProtParam import ProteinAnalysis

st.set_page_config(page_title='Antigen Lookup', page_icon='🧬', layout='wide')
st.title('Antigen Lookup | BLI / SPR')
st.caption('Evidence-first intake assistant. Unverified fields stay blank. Review all results before experimental use.')
HEAD={'User-Agent':'Mozilla/5.0 (compatible; AntigenLookup/0.1)'}
FIELDS=['Target Antigen Name','Target Antigen Tags','Target Antigen Supplier','Supplied Target Antigen Storage Conditions','Supplied Target Antigen Details (Formulation/Storage Buffer)','Vendor-Supplied Target Antigen (URL and Catalog #)','Target Antigen Requests','Molecular Weight (kDa)','Extinction Coefficient (M-1cm-1)','Oligomeric Condition','Affinity','Homology']

def get(url):
    try:
        r=requests.get(url,headers=HEAD,timeout=18);r.raise_for_status();return r
    except requests.RequestException:return None

def uniprot(acc):
    r=get(f'https://rest.uniprot.org/uniprotkb/{quote(acc)}.json')
    if not r:return None
    try:return r.json()
    except ValueError:return None

def classify(x):
    x=x.strip()
    if re.match(r'^https?://',x,re.I):return 'url'
    if re.fullmatch(r'(?:[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9](?:[A-Z][A-Z0-9]{2}[0-9]){1,2})(?:-\d+)?',x,re.I):return 'uniprot'
    if re.fullmatch(r'\d{4,7}-[A-Za-z0-9-]+',x):return 'catalog'
    return 'name'

def lookup(raw, vendor='Auto', exact_sequence='', source_sequence=''):
    raw=str(raw).strip();kind=classify(raw)
    values={k:'' for k in FIELDS}; evidence=[]; alerts=[]
    def put(k,v,confidence,source,note=''):
        values[k]=v;evidence.append({'Field':k,'Value':v,'Confidence':confidence,'Source':source,'Notes':note})
    if vendor!='Auto':put('Target Antigen Supplier',vendor,'User-provided','User input')
    if kind=='catalog':
        if vendor in ('Auto','Sino Biological'):
            put('Target Antigen Supplier','Sino Biological','Inferred','Catalog format; confirm product match')
            alerts.append('Catalog format resembles Sino Biological. Exact product page has not been verified. Paste the manufacturer URL for source extraction.')
        else:alerts.append('Catalog supplied without a verified product URL. Product-specific properties withheld.')
        put('Vendor-Supplied Target Antigen (URL and Catalog #)',raw,'User-provided','User input')
    if kind=='name':put('Target Antigen Name',raw,'User-provided','User input')
    if kind=='uniprot':
        data=uniprot(raw)
        if data:
            nm=data.get('proteinDescription',{}).get('recommendedName',{}).get('fullName',{}).get('value','')
            put('Target Antigen Name',nm or raw,'Reference only','UniProt '+raw,'Canonical protein identity; not necessarily vendor construct')
            alerts.append('UniProt describes a reference sequence, not the exact commercial construct. Vendor-specific values withheld.')
        else:alerts.append('UniProt record unavailable; check accession and internet access.')
    if kind=='url':
        host=urlparse(raw).netloc.lower()
        known={'sinobiological.com':'Sino Biological','acrobiosystems.com':'ACROBiosystems','genscript.com':'GenScript'}
        supplier=next((v for k,v in known.items() if host==k or host.endswith('.'+k)),None)
        if supplier:put('Target Antigen Supplier',supplier,'Verified domain',raw)
        else:alerts.append('URL is not from a recognized supplier; confirm source manually.')
        put('Vendor-Supplied Target Antigen (URL and Catalog #)',raw,'User-provided','User input')
        response=get(raw)
        if response:
            soup=BeautifulSoup(response.text,'html.parser')
            for t in soup(['script','style','nav','footer']):t.decompose()
            title=soup.title.get_text(' ',strip=True) if soup.title else ''
            if title:put('Target Antigen Name',title[:180],'Product page title',raw,'Page title only; confirm actual protein identity')
            page=soup.get_text(' ',strip=True)
            st.session_state.setdefault('raw_page_cache',{})[raw]=page[:40000]
            alerts.append('Product page retrieved. Manufacturer text is available for manual review; no MW, buffer, affinity, or oligomeric state is inferred from unstructured text.')
        else:alerts.append('Could not retrieve product page; it may block automated requests.')
    if exact_sequence.strip():
        seq=re.sub(r'\s+','',exact_sequence).upper()
        if re.fullmatch('[ACDEFGHIKLMNPQRSTVWY]+',seq):
            if not source_sequence.strip():
                alerts.append('Sequence provided but no verification source. Extinction coefficient not automatically accepted.')
            else:
                p=ProteinAnalysis(seq)
                er,eo=p.molar_extinction_coefficient()
                put('Extinction Coefficient (M-1cm-1)',str(er) if er==eo else '', 'Calculated / conditional',source_sequence.strip(),f'Exact sequence claimed verified. Reduced ε={er:,}; maximum oxidized ε={eo:,} M⁻¹cm⁻¹. Blank when disulfide state changes value.')
                if er!=eo:alerts.append(f'Extinction coefficient depends on disulfides: reduced {er:,}; maximum oxidized {eo:,}. No single high-confidence value selected.')
                else:alerts.append(f'Calculated ε280={er:,} M⁻¹cm⁻¹; confirm the supplied sequence is the full mature construct.')
        else:alerts.append('Invalid sequence characters; extinction coefficient withheld.')
    if not evidence:alerts.append('No verified manufacturer data found. Provide a direct product URL or verified construct sequence.')
    return values,evidence,alerts

with st.sidebar:
    st.header('Settings')
    vendor=st.selectbox('Supplier',['Auto','Sino Biological','ACROBiosystems','GenScript'])
    st.info('High-confidence mode: missing or ambiguous values remain blank. Exact product matching and CoA discovery require manufacturer-accessible documentation.')

tab1,tab2=st.tabs(['Single lookup','Batch lookup'])
with tab1:
    query=st.text_input('Antigen name, UniProt accession, catalog number, or product URL',value='10052-H08H')
    with st.expander('Optional verified expressed sequence (for ε280 calculation)'):
        seq=st.text_area('Exact mature construct amino-acid sequence (including tags and linkers)')
        seqsrc=st.text_input('Sequence verification source (manufacturer document URL or CoA reference)')
    if st.button('Look up antigen',type='primary'):
        with st.spinner('Checking sources...'):st.session_state.result=lookup(query,vendor,seq,seqsrc)
    if 'result' in st.session_state:
        vals,ev,warnings=st.session_state.result
        for w in warnings:st.warning(w)
        st.subheader('Intake fields')
        st.dataframe(pd.DataFrame([{'Field':k,'Value':v} for k,v in vals.items()]),hide_index=True,use_container_width=True)
        st.subheader('Evidence audit')
        st.dataframe(pd.DataFrame(ev,columns=['Field','Value','Confidence','Source','Notes']),hide_index=True,use_container_width=True)
        out=io.BytesIO()
        with pd.ExcelWriter(out,engine='xlsxwriter') as writer:
            pd.DataFrame([{'Field':k,'Value':v} for k,v in vals.items()]).to_excel(writer,'Intake',index=False)
            pd.DataFrame(ev,columns=['Field','Value','Confidence','Source','Notes']).to_excel(writer,'Evidence',index=False)
            pd.DataFrame({'Warnings':warnings}).to_excel(writer,'Review flags',index=False)
        st.download_button('Download Excel',out.getvalue(),file_name='antigen_intake.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        if classify(query)=='url' and query in st.session_state.get('raw_page_cache',{}):
            with st.expander('Manufacturer page text for review'):
                st.text_area('Extracted content',st.session_state.raw_page_cache[query],height=250)
with tab2:
    file=st.file_uploader('CSV or XLSX with one column containing antigen names, accessions, catalog numbers, or URLs',type=['csv','xlsx'])
    if file:
        try:df=pd.read_csv(file) if file.name.lower().endswith('.csv') else pd.read_excel(file)
        except Exception as e:st.error(f'Could not read file: {e}');st.stop()
        col=st.selectbox('Lookup column',list(df.columns))
        if st.button('Run batch'):
            rows=[];audit=[];flags=[];bar=st.progress(0)
            for i,x in enumerate(df[col].fillna('').astype(str)):
                vals,ev,ws=lookup(x,vendor)
                rows.append({'Input':x,**vals});audit.extend([{'Input':x,**e} for e in ev]);flags.extend([{'Input':x,'Flag':w} for w in ws]);bar.progress((i+1)/len(df))
                time.sleep(.1)
            buf=io.BytesIO()
            with pd.ExcelWriter(buf,engine='xlsxwriter') as writer:
                pd.DataFrame(rows).to_excel(writer,'Intake',index=False)
                pd.DataFrame(audit).to_excel(writer,'Evidence',index=False)
                pd.DataFrame(flags).to_excel(writer,'Review flags',index=False)
            st.download_button('Download batch results',buf.getvalue(),'antigen_batch.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
