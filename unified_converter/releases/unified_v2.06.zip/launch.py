"""Load this release's sources on the Python runtime, outside the browser editor."""
import json
from pathlib import Path

def initialize(directory):
    directory=Path(directory)
    sources=json.loads((directory/'sources.json').read_text())
    runtime={'__name__':'sw_tools_runtime'}
    exec(compile((directory/'runtime.py').read_text(),'runtime.py','exec'),runtime)
    return runtime['initialize'](sources,directory/'engine')

def start(directory):
    directory=Path(directory)
    engine=initialize(directory)
    ui={'__name__':'sw_tools_ui','__file__':str(directory/'colab_ui.py')}
    exec(compile((directory/'colab_ui.py').read_text(),'colab_ui.py','exec'),ui)
    controls=ui['show_converter'](engine['run_unified'])
    return engine,controls
