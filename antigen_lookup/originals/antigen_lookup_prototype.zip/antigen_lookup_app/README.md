# Antigen Lookup (early prototype)

## Install and launch

Requires Python 3.10+ and internet access.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

On Windows, activate with `.venv\\Scripts\\activate`.

## Scope and limitations

This is an **early conservative prototype**, not a fully automated manufacturer-research engine. It supports single and batch inputs, UniProt identity lookup, retrieving vendor page text for manual inspection, evidence logs, and Excel exports. It **does not** yet automatically find exact manufacturer catalog pages from catalog numbers, search manufacturer PDFs/CoAs, extract vendor properties into fields, validate an asserted sequence against its cited source, or compute reliable BLI/SPR MW from construct details. A supplied sequence with a source reference can produce a theoretical ε280 only when reduced and maximum oxidized results agree. No unsupported value is auto-filled.

A next production stage requires manufacturer search adapters, PDF parsers, construct-aware matching, and a verifiable source extraction/review layer. This prototype is intended to establish UI and evidence policy, not to replace scientific review.
